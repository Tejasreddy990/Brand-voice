import { useState } from "react";
import {
  ArrowRight, Sparkles, Copy, Check, RefreshCw, MessageSquareText,
  Target, WandSparkles, LoaderCircle, TriangleAlert, Heart
} from "lucide-react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const objectives = [
  { value: "Engagement", label: "Engagement", description: "Replies, likes and conversation" },
  { value: "Promotion", label: "Promotion", description: "Promote a product or service" },
  { value: "Brand awareness", label: "Brand awareness", description: "Reach and recognition" },
  { value: "Education", label: "Education", description: "Tips, insights and value" }
];

const tones = [
  "Let AI decide",
  "Funny and witty",
  "Professional and informative",
  "Bold and motivational",
  "Premium and minimal"
];

const types = {
  "Conversational": "conversation",
  "Promotional": "promotion",
  "Witty / meme-style": "witty",
  "Informative / value-driven": "informative"
};

export default function App() {
  const [form, setForm] = useState({
    brandName: "",
    industry: "",
    objective: "Engagement",
    products: "",
    tone: "Let AI decide"
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState("");

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  async function generateTweets(event) {
    event?.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const response = await fetch(`${API_URL}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      setResult(data);
    } catch (err) {
      setError(err.message || "Could not connect to the server. Is the backend running?");
    } finally {
      setLoading(false);
    }
  }

  async function copyText(text, id) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      setTimeout(() => setCopied(""), 1600);
    } catch {
      setError("Clipboard access failed. Please select and copy the text manually.");
    }
  }

  async function copyAll() {
    if (!result) return;
    const text = [
      "BRAND VOICE SUMMARY",
      ...result.brandVoiceSummary.map((point) => `• ${point}`),
      "",
      "10 GENERATED TWEETS",
      ...result.tweets.map((tweet, i) => `${i + 1}. [${tweet.type}] ${tweet.text}`)
    ].join("\n");
    await copyText(text, "all");
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand-lockup" href="#" aria-label="BrandVoice home">
          <span className="brand-mark"><MessageSquareText size={20} /></span>
          <span>brandvoice<span className="brand-dot">.</span></span>
        </a>
        <span className="top-label"><span className="status-dot" /> AI CONTENT STUDIO</span>
      </header>

      <main>
        <section className="hero">
          <div className="eyebrow"><Sparkles size={14} /> YOUR BRAND, YOUR VOICE</div>
          <h1>Ideas that sound<br /><span>like your brand.</span></h1>
          <p className="hero-copy">
            Turn a few brand details into 10 thoughtful, on-brand tweets.
            Less blank-page anxiety. More ideas worth sharing.
          </p>
          <div className="hero-pills">
            <span><WandSparkles size={14} /> Brand voice insights</span>
            <span><MessageSquareText size={14} /> 10 tweet ideas</span>
            <span><Target size={14} /> Campaign-aware</span>
          </div>
        </section>

        <div className="workspace">
          <section className="form-panel">
            <div className="panel-heading">
              <div>
                <div className="step-label">STEP 01</div>
                <h2>Tell us about your brand</h2>
                <p>The more context you share, the more relevant the ideas.</p>
              </div>
              <div className="heading-icon"><WandSparkles size={21} /></div>
            </div>

            <form onSubmit={generateTweets}>
              <div className="field-grid">
                <label className="field">
                  <span>Brand name <em>OPTIONAL</em></span>
                  <input value={form.brandName} onChange={(e) => update("brandName", e.target.value)}
                    placeholder="e.g. Northstar Studio" maxLength={1200} />
                </label>
                <label className="field">
                  <span>Industry / category <em>OPTIONAL</em></span>
                  <input value={form.industry} onChange={(e) => update("industry", e.target.value)}
                    placeholder="e.g. Sustainable fashion" maxLength={1200} />
                </label>
              </div>

              <fieldset className="field objective-field">
                <legend>What's your campaign goal?</legend>
                <div className="objective-grid">
                  {objectives.map((item) => (
                    <button type="button" key={item.value}
                      className={`objective-card ${form.objective === item.value ? "selected" : ""}`}
                      onClick={() => update("objective", item.value)}>
                      <span className="objective-radio">{form.objective === item.value && <span />}</span>
                      <strong>{item.label}</strong>
                      <small>{item.description}</small>
                    </button>
                  ))}
                </div>
              </fieldset>

              <label className="field">
                <span>Products or services <b className="required">*</b></span>
                <textarea value={form.products} onChange={(e) => update("products", e.target.value)}
                  placeholder="What do you offer? What makes it useful or different?" rows={4}
                  maxLength={1200} required />
                <small className="field-hint">{form.products.length}/1200 characters</small>
              </label>

              <label className="field">
                <span>Preferred tone</span>
                <select value={form.tone} onChange={(e) => update("tone", e.target.value)}>
                  {tones.map((tone) => <option key={tone} value={tone}>{tone}</option>)}
                </select>
              </label>

              <button className="generate-button" type="submit" disabled={loading || !form.products.trim()}>
                {loading ? <><LoaderCircle className="spin" size={18} /> Creating your tweets...</> :
                  <><Sparkles size={18} /> Generate 10 tweets <ArrowRight size={17} /></>}
              </button>
              <p className="privacy-note">Your brand details are used to generate this result and are not saved by this app.</p>
            </form>
          </section>

          <section className="results-panel">
            {!result && !loading && !error && (
              <div className="empty-state">
                <div className="empty-art">
                  <div className="art-card art-card-back"><span /><span /><span /></div>
                  <div className="art-card art-card-front">
                    <div className="art-spark"><Sparkles size={22} /></div>
                    <span className="art-line long" /><span className="art-line" /><span className="art-line short" />
                    <div className="art-footer"><Heart size={15} /><span /><span /></div>
                  </div>
                </div>
                <div className="step-label">STEP 02</div>
                <h2>Your next great post<br />starts here.</h2>
                <p>Fill in your brand details and your voice summary and 10 tweet ideas will appear here.</p>
                <div className="empty-tags"><span>01 Voice summary</span><span>02 Tweet collection</span></div>
              </div>
            )}

            {loading && (
              <div className="loading-state">
                <div className="loader-orb"><Sparkles size={30} /></div>
                <h2>Finding your brand voice...</h2>
                <p>Thinking through tone, audience and fresh angles.</p>
                <div className="loading-bars"><i /><i /><i /></div>
              </div>
            )}

            {error && (
              <div className="error-state">
                <TriangleAlert size={30} />
                <h2>We hit a small snag</h2>
                <p>{error}</p>
                <button className="secondary-button" onClick={generateTweets}><RefreshCw size={15} /> Try again</button>
              </div>
            )}

            {result && (
              <div className="result-content">
                <div className="result-topline">
                  <div>
                    <div className="step-label">STEP 02 · YOUR RESULTS</div>
                    <h2>Your brand, in words.</h2>
                    <p>Generated for {form.brandName.trim() || "your brand"}</p>
                  </div>
                  <span className={`mode-tag ${result.mode === "ai" ? "live" : ""}`}>
                    <span /> {result.mode === "ai" ? "AI GENERATED" : "DEMO MODE"}
                  </span>
                </div>

                <div className="voice-card">
                  <div className="voice-card-title"><span className="voice-icon"><Sparkles size={16} /></span>
                    <div><h3>Brand voice snapshot</h3><p>Our read on your brand personality</p></div>
                  </div>
                  <ul>{result.brandVoiceSummary.map((point, index) =>
                    <li key={index}><span className="summary-bullet">{String(index + 1).padStart(2, "0")}</span>{point}</li>
                  )}</ul>
                </div>

                <div className="tweets-heading">
                  <div><h3>Your 10 tweet ideas</h3><p>A mix of angles, ready to refine and share.</p></div>
                  <button className="secondary-button copy-all" onClick={copyAll}>
                    {copied === "all" ? <Check size={15} /> : <Copy size={15} />}
                    {copied === "all" ? "Copied all" : "Copy all"}
                  </button>
                </div>

                <div className="tweet-list">
                  {result.tweets.map((tweet, index) => (
                    <article className="tweet-card" key={tweet.id || index}>
                      <div className="tweet-meta">
                        <span className="tweet-number">{String(index + 1).padStart(2, "0")}</span>
                        <span className={`tweet-type ${types[tweet.type] || "other"}`}>{tweet.type}</span>
                        <button className="copy-button" title="Copy tweet" onClick={() => copyText(tweet.text, String(index))}>
                          {copied === String(index) ? <Check size={15} /> : <Copy size={15} />}
                          <span>{copied === String(index) ? "Copied" : "Copy"}</span>
                        </button>
                      </div>
                      <p className="tweet-text">{tweet.text}</p>
                      <div className="tweet-bottom"><span>POST IDEA {String(index + 1).padStart(2, "0")}</span><span>{tweet.text.length} characters</span></div>
                    </article>
                  ))}
                </div>

                <button className="generate-button regenerate" onClick={generateTweets} disabled={loading}>
                  <RefreshCw size={17} /> Generate another set
                </button>
                <p className="disclaimer">Review generated content for accuracy and brand fit before publishing.</p>
              </div>
            )}
          </section>
        </div>
      </main>
      <footer><span>brandvoice<span className="brand-dot">.</span></span><span>Made for ideas that sound like you.</span></footer>
    </div>
  );
}
