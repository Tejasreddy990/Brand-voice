import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));

const categories = [
  "Conversational",
  "Conversational",
  "Promotional",
  "Promotional",
  "Promotional",
  "Witty / meme-style",
  "Witty / meme-style",
  "Informative / value-driven",
  "Informative / value-driven",
  "Informative / value-driven"
];

function validateInput(body = {}) {
  const objective = String(body.objective || "").trim();
  const allowedObjectives = ["Engagement", "Promotion", "Brand awareness", "Education"];
  if (!allowedObjectives.includes(objective)) {
    return "Please choose a valid campaign objective.";
  }

  const tone = String(body.tone || "Let AI decide").trim();
  const allowedTones = [
    "Let AI decide",
    "Funny and witty",
    "Professional and informative",
    "Bold and motivational",
    "Premium and minimal"
  ];
  if (!allowedTones.includes(tone)) return "Please choose a valid tone.";

  const products = String(body.products || "").trim();
  if (!products) return "Please describe the brand's products or services.";

  for (const key of ["brandName", "industry", "products"]) {
    if (typeof body[key] === "string" && body[key].length > 1200) {
      return "Please keep each field under 1,200 characters.";
    }
  }
  return null;
}

function demoResult(input) {
  const brand = input.brandName.trim() || "Your brand";
  const industry = input.industry.trim() || "your industry";
  const product = input.products.trim();
  const tone = input.tone === "Let AI decide"
    ? "friendly, clear and audience-focused"
    : input.tone.toLowerCase();

  const summary = [
    `Likely tone: ${tone}, adapted to the ${industry} category.`,
    "Target audience: people likely to benefit from the products or services described.",
    `Content themes: ${product}, everyday use cases, and audience conversations.`,
    `Campaign focus: ${input.objective.toLowerCase()}, using concise and varied social copy.`
  ];

  const samples = [
    `Let's talk about ${product.toLowerCase()}: what's the one thing you wish more people knew about it?`,
    `Quick question for the community: what matters most to you when choosing ${industry.toLowerCase()} products?`,
    `Meet a simpler way to think about ${product.toLowerCase()}. Explore what works best for you.`,
    `Your next great ${industry.toLowerCase()} discovery might start with one small change. What would you try first?`,
    `A little reminder from ${brand}: the best choice is the one that fits your needs. What are yours?`,
    `POV: you finally find a ${industry.toLowerCase()} solution that makes sense for your day. 😌`,
    `Plan: keep it simple. Plot twist: you discover even more ways to use ${product.toLowerCase()}.`,
    `Helpful tip: list your top priority before comparing options. It makes decisions about ${industry.toLowerCase()} products easier.`,
    `Think about the problem you want to solve first, then match it to the features that matter. That's a useful starting point for ${product.toLowerCase()}.`,
    `Your turn: share one question you have about ${industry.toLowerCase()}, and let's get the conversation going.`
  ];

  return {
    brandVoiceSummary: summary,
    tweets: samples.map((text, index) => ({
      id: index + 1,
      type: categories[index],
      text
    })),
    mode: "demo"
  };
}

function extractJson(text) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  return JSON.parse(cleaned);
}

function normalizeResult(parsed) {
  if (!Array.isArray(parsed.brandVoiceSummary) || !Array.isArray(parsed.tweets)) {
    throw new Error("The AI response did not contain the required fields.");
  }
  const summary = parsed.brandVoiceSummary
    .filter((item) => typeof item === "string" && item.trim())
    .slice(0, 4);
  const tweets = parsed.tweets
    .filter((item) => item && typeof item.text === "string" && item.text.trim())
    .slice(0, 10)
    .map((item, index) => ({
      id: index + 1,
      type: String(item.type || categories[index]),
      text: item.text.trim()
    }));

  if (summary.length < 3 || tweets.length !== 10) {
    throw new Error("The AI response did not contain 3–4 summary points and exactly 10 tweets.");
  }
  return { brandVoiceSummary: summary, tweets, mode: "ai" };
}

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/generate", async (req, res) => {
  const input = {
    brandName: String(req.body?.brandName || ""),
    industry: String(req.body?.industry || ""),
    objective: String(req.body?.objective || ""),
    products: String(req.body?.products || ""),
    tone: String(req.body?.tone || "Let AI decide")
  };

  const error = validateInput(input);
  if (error) return res.status(400).json({ error });

  if (!process.env.OPENAI_API_KEY) {
    return res.json(demoResult(input));
  }

  try {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = `
You are a careful social media strategist. Infer an estimated brand voice only from the information supplied below. Do not claim you inspected social media posts. Do not invent facts, discounts, product features, statistics, or guarantees.

Brand name: ${input.brandName || "Not provided"}
Industry/category: ${input.industry || "Not provided"}
Campaign objective: ${input.objective}
Product/service information: ${input.products}
Preferred tone: ${input.tone}

Return ONLY valid JSON with this shape:
{
  "brandVoiceSummary": ["3 or 4 concise bullet points as strings"],
  "tweets": [
    {"type": "Conversational", "text": "..."}
  ]
}

Requirements:
- Generate exactly 10 original tweets.
- Provide 3–4 brand voice summary points covering tone, likely audience, themes and objective.
- Use this content mix: 2 Conversational, 3 Promotional, 2 Witty / meme-style, 3 Informative / value-driven.
- Adapt the mix to the campaign objective without losing variety.
- Keep each tweet concise and suitable for X.
- Use a natural voice, distinct ideas and varied sentence structures.
- Do not state unprovided claims as facts. Avoid fake discounts, fake metrics, or made-up product features.
- If brand details are limited, be transparent in the summary and create safe, general content from the supplied information.
- Do not add hashtags unless they are genuinely useful; do not force emojis.
- Use plain text in each tweet.`;

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      input: prompt
    });

    const rawText = response.output_text;
    if (!rawText) throw new Error("The AI provider returned an empty response.");
    const result = normalizeResult(extractJson(rawText));
    return res.json(result);
  } catch (err) {
    console.error("Generation error:", err.message);
    return res.status(502).json({
      error: "Could not generate tweets right now. Check the AI API key/model and try again, or run in demo mode by clearing OPENAI_API_KEY."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Brand Tweet Generator API running at http://localhost:${PORT}`);
});
