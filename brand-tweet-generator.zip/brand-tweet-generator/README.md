# AI-Powered Brand Tweet Generator

A small full-stack app that accepts brand details and generates a brand voice summary plus 10 tweets.

## Tech stack
- React + Vite frontend
- Node.js + Express backend
- OpenAI API (optional; demo mode works without an API key)

## Requirements
- Node.js 18 or newer
- npm
- An OpenAI API key to use live AI generation (optional for demo mode)

## Run locally (Windows PowerShell)

1. Extract the ZIP and open the `brand-tweet-generator` folder in VS Code.
2. Open a terminal in that folder and install the root development dependency:

   ```powershell
   npm install
   ```

3. Install backend and frontend dependencies:

   ```powershell
   npm run install:all
   ```

4. Create the backend environment file:

   ```powershell
   Copy-Item server/.env.example server/.env
   ```

5. Open `server/.env`. To use real AI generation, paste your API key after `OPENAI_API_KEY=`. Keep this file private and never put the key in the frontend. If you leave the key blank, the app uses demo mode.

6. Start both parts:

   ```powershell
   npm run dev
   ```

7. Open http://localhost:5173

The backend runs on http://localhost:5000.

## How it works
1. React collects brand name, industry, campaign objective, product details, and optional tone.
2. React sends the input to `POST /api/generate`.
3. Express validates the input and calls the AI model when an API key is configured.
4. The backend returns a JSON voice summary and 10 tweets.
5. React displays the results and provides copy buttons.

## API endpoint
`POST http://localhost:5000/api/generate`

Example request:
```json
{
  "brandName": "Zomato",
  "industry": "Food delivery",
  "objective": "Engagement",
  "products": "Food delivery and restaurant discovery",
  "tone": "Let AI decide"
}
```

## Important notes
- Demo mode is intended to test the interface; its sample output is not real AI generation.
- Brand voice is inferred from the information supplied. This app does not automatically verify recent social posts.
- Do not claim discounts, features, statistics, or other brand facts unless the user provides them or they are verified.
- Before public deployment, configure environment variables on your hosting provider and add rate limiting / usage limits to protect the API.
- This starter does not save user data and does not require a database.
